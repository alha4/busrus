<?php
 namespace B24Entity\Http;

 interface IHttp {
    public function getRequest();
 }