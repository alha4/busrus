<?php
 namespace B24Entity\Helpers;

 interface IEncoder {
     public function encode($data);  
 }